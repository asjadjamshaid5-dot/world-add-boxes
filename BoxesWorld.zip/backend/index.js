const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

// Subscription stub
app.post('/subscribe', (req, res) => {
  res.json({ message: 'Subscription endpoint (stub)' });
});

// Webhook stub
app.post('/webhook', (req, res) => {
  res.json({ message: 'Webhook endpoint (stub)' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));