function createBox() {
  const box = document.createElement('div');
  box.className = 'box';
  box.innerHTML = '<h3>New Box</h3><p>This is your box content.</p>';
  document.getElementById('boxes').appendChild(box);
}